def test_whl_fn1():
    print('test_whl_fn1 has been called.')
